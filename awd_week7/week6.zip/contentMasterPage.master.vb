﻿
Partial Class rightsideMasterPage
    Inherits System.Web.UI.MasterPage
End Class

